### Hexlet tests and linter status:
[![Actions Status](https://github.com/Viewsoul237/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Viewsoul237/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/7e4d2c87224589c0c292/maintainability)](https://codeclimate.com/github/Viewsoul237/python-project-49/maintainability)

https://asciinema.org/a/LLgcffLzqnRqwRXuNeSzkVHhy
