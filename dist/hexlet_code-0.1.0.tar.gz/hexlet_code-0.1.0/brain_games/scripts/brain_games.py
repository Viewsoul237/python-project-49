#!/usr/bin/env python3

def say_welcome():
    print("Welcome to the Brain Games!")


def main():
    say_welcome()


if __name__ == "__main__":
    main()
