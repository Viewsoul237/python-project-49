### Hexlet tests and linter status:
[![Actions Status](https://github.com/Viewsoul237/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Viewsoul237/python-project-49/actions)