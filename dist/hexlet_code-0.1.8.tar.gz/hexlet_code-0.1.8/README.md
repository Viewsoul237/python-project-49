### Hexlet tests and linter status:
[![Actions Status](https://github.com/Viewsoul237/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Viewsoul237/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/7e4d2c87224589c0c292/maintainability)](https://codeclimate.com/github/Viewsoul237/python-project-49/maintainability)

## [Пример работы игры 'Четное или нечетное'](https://asciinema.org/a/E2NI7GyRSsfAe6x47zjovfayT)

## [Пример работы игры 'Калькулятор'](https://asciinema.org/a/J0vL291RCEtqFWnLqZHutvGxE)

## [Пример работы игры 'Нахождение общего делителя (НОД)'](https://asciinema.org/a/Ubtv8BYOe8PzaMulUGLw2eC1y)
